package com.stacksimplify.restservices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootBuildingblocksApplicationTests {

	@Test
	void contextLoads() {
	}

}
